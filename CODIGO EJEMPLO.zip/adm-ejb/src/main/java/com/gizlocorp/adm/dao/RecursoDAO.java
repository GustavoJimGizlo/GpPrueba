package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Recurso;


@Local
public interface RecursoDAO extends GenericDAO<Recurso, String>{
	
	List<Recurso> obtenerPorBasico(String codigo, String nombre);
	Recurso obtenerPorURL(String url) throws GizloException;

}
