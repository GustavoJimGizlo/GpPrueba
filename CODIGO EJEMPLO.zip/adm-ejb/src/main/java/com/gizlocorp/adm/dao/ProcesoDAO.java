package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.modelo.Proceso;

@Local
public interface ProcesoDAO extends GenericDAO<Proceso, Long> {

	List<Proceso> obtenerProcesos(String tipo, String nombre);

}
