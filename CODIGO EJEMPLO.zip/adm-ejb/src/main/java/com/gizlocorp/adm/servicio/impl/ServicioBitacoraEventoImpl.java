package com.gizlocorp.adm.servicio.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.dao.BitacoraEventoDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Bitacora;
import com.gizlocorp.adm.modelo.BitacoraEvento;
import com.gizlocorp.adm.servicio.local.ServicioBitacoraEventoLocal;

@Stateless
public class ServicioBitacoraEventoImpl implements ServicioBitacoraEventoLocal {

	private static Logger log = Logger
			.getLogger(ServicioBitacoraEventoImpl.class.getName());

	@Resource(mappedName = "java:/queue/bitacoraEventosQueue")
	private Queue queue;

	@Resource(mappedName = "java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;

	@EJB
	BitacoraEventoDAO bitacoraEventoDAO;

	@Override
	public List<BitacoraEvento> obtenerEventoReproceso(String codigoEvento)
			throws GizloException {
		return bitacoraEventoDAO.obtenerEventoReproceso(codigoEvento);
	}

	@Override
	public BitacoraEvento actualizarBitacoraEvento(BitacoraEvento bitacoraEvento) {
		BitacoraEvento respuesta = null;
		try {
			if (bitacoraEvento.getId() == null) {
				bitacoraEventoDAO.persist(bitacoraEvento);
				respuesta = bitacoraEvento;
			} else {
				respuesta = bitacoraEventoDAO.update(bitacoraEvento);
			}
		} catch (Exception ex) {
			respuesta = null;
			log.error(
					"Ha ocurrido un error al grabar en la bitcora de eventos: ",
					ex);
		}

		return respuesta;
	}

	@Override
	public List<BitacoraEvento> obtenerEventosPorParametros(Long idEvento,
			String usuario, Date fechaDesde, Date fechaHasta,
		String detalle) throws GizloException {
		return bitacoraEventoDAO.obtenerEventosPorParametros(idEvento, usuario,
				fechaDesde, fechaHasta, detalle);
	}

	@Override
	public List<BitacoraEvento> obtenerEvento(String codigoEvento,
			Long idOrganizacion) throws GizloException {
		return bitacoraEventoDAO.obtenerEvento(codigoEvento, idOrganizacion);
	}

	@Override
	public void insertaEventoMdb(Bitacora bitacoraEvento) {
		javax.jms.Connection connection = null;
		Session session = null;
		try {
			connection = this.connectionFactory.createConnection();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = session.createProducer(this.queue);
			ObjectMessage objmsg = session.createObjectMessage();
			// Map<String,BitacoraEvento> specs = new
			// HashMap<String,BitacoraEvento>();
			// specs.put("bitacora", bitacoraEvento);
			objmsg.setObject(bitacoraEvento);
			producer.send(objmsg);

		} catch (Exception e) {
			log.error("Error proceso automatico", e);
		} finally {
			if (session != null) {
				try {
					session.close();
				} catch (JMSException e) {
					log.error("Error proceso automatico", e);
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					log.error("Error proceso automatico", e);
				}
			}
		}

	}
}