package com.gizlocorp.adm.enumeracion;

public enum ModoEnvio {
	
	ONLINE("ONLINE"), OFFLINE("OFFLINE");

	private String descripcion;

	private ModoEnvio(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

}
