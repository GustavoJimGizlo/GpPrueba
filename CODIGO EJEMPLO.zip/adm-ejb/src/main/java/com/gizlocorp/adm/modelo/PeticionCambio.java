package com.gizlocorp.adm.modelo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.gizlocorp.adm.enumeracion.Estado;
/**
 * 
 * @author ronald.barrera@gizlocorp.com, Consultor IT
 * cambio contrasena
 */
@Entity
@Table(name = "tb_peticion_cambio")
public class PeticionCambio implements Serializable {
	
	private static final long serialVersionUID = -8480330170794777331L;

	@Id
	@SequenceGenerator(name = "seq_peticion_cambio", sequenceName = "seq_peticion_cambio", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_peticion_cambio")
	@Column(name = "id", nullable = false)
	private Long id;
	
	@Column(name = "username", length = 50, nullable = false)
	protected String username;
	
	@Column(name = "provisional", length = 50, nullable = false)
	protected String provisional;
	
	@Column(name = "codigo", length = 50)
	protected String codigo;
	
	@Column(name = "fecha", length = 50)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fecha;

	//ACT estan pendientes FIN Finalizadas
	@Column(name = "estado", nullable = false, length = 3)
	@Enumerated(EnumType.STRING)
	private Estado estado;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}

	public String getProvisional() {
		return provisional;
	}

	public void setProvisional(String provisional) {
		this.provisional = provisional;
	}

	
}
