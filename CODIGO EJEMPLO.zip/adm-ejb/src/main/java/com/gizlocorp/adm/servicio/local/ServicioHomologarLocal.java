package com.gizlocorp.adm.servicio.local;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.HomologarMensaje;

@Local
public interface ServicioHomologarLocal {

	List<HomologarMensaje> obtenerMensajes(String nombre, String errorAplicacion) throws GizloException;
	
	void guardar(HomologarMensaje homologarMensaje) throws GizloException;
	

}
