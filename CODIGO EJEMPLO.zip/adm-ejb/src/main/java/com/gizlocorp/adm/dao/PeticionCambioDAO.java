package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.modelo.PeticionCambio;

@Local
public interface PeticionCambioDAO extends GenericDAO<PeticionCambio, Long> {

	public PeticionCambio buscarPeticion(String peticion);
	
	public List<PeticionCambio> buscarPendientesUsuario(String usuario);
	
}
