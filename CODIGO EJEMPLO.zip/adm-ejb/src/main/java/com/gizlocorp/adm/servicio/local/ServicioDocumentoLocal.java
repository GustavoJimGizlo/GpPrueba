package com.gizlocorp.adm.servicio.local;

import java.io.IOException;

import javax.ejb.Local;

@Local
public interface ServicioDocumentoLocal {

	String crearComprobante(String xmlSource, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws IOException;

	String crearComprobante(byte[] xml, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws Exception;

}
