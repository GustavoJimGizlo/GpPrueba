package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.HomologarMensaje;

@Local
public interface HomologarMensajesDAO extends GenericDAO<HomologarMensaje, Long> {

	List<HomologarMensaje> obtenerMensajes(String nombre, String errorAplicacion) throws GizloException;

}
