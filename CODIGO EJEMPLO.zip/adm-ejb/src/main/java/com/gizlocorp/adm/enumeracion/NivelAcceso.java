/**
 * 
 */
package com.gizlocorp.adm.enumeracion;

/**
 * 
 * @author
 * @version $Revision: 1.0 $
 */
public enum NivelAcceso {
	LECTURA, INSERCION, ACTUALIZACION, ELIMINACION;

	private NivelAcceso() {
	}
}
