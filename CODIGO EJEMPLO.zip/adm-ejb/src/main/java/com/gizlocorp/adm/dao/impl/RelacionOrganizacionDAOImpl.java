package com.gizlocorp.adm.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.dao.RelacionOrganizacionDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.RelacionOrganizacion;
import com.gizlocorp.adm.servicio.impl.ServicioRelacionOrganizacionImpl;

@Stateless
public class RelacionOrganizacionDAOImpl extends
		GenericJpaDAO<RelacionOrganizacion, Long> implements
		RelacionOrganizacionDAO {
	
	public static final Logger log = Logger
			.getLogger(RelacionOrganizacionDAOImpl.class);

	@SuppressWarnings("unchecked")
	public boolean existeRelacionOrganizacion(String ruc, String rucRelacion,
			String tipoRelacion) throws GizloException {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from RelacionOrganizacion c where c.organizacion.ruc = :ruc ");
		sql.append("and c.organizacionRelacion.ruc = :rucRelacion ");
		sql.append("and c.tipoRelacion = :tipoRelacion  ");

		mapa.put("ruc", ruc);
		mapa.put("rucRelacion", rucRelacion);
		mapa.put("tipoRelacion", tipoRelacion);

		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}

		List<RelacionOrganizacion> result = q.getResultList();
		return result == null || result.isEmpty() ? false : true;

	}

	@SuppressWarnings("unchecked")
	public List<RelacionOrganizacion> buscarPorParametros(String ruc,
			String nombre, String tipoRelacon) throws GizloException {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from RelacionOrganizacion c where 1=1 ");

		if (ruc != null && !ruc.isEmpty()) {
			sql.append("and c.organizacion.ruc = :ruc ");
			mapa.put("ruc", ruc);
		}

		if (nombre != null && !nombre.isEmpty()) {
			sql.append("and upper(c.organizacion.nombre) like :nombre ");
			mapa.put("nombre", "%" + nombre.toUpperCase() + "%");
		}

		if (tipoRelacon != null && !tipoRelacon.isEmpty()) {
			sql.append("and c.tipoRelacion = :tipoRelacon ");
			mapa.put("tipoRelacon", tipoRelacon);
		}

		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}

		List<RelacionOrganizacion> result = q.getResultList();
		return result == null || result.isEmpty() ? null : result;
	}
	
	@SuppressWarnings("unchecked")
	public List<RelacionOrganizacion> buscarPorParametrosAll(String rucOrganizacion,
			String rucPersona, String tipoRelacon) throws GizloException {
		try{
			StringBuilder sql = new StringBuilder();
			HashMap<String, Object> mapa = new HashMap<String, Object>();
			
			log.info("***buscarPorParametrosAll***");
			
			sql.append("select c from RelacionOrganizacion c where 1=1 ");
	
			if (rucOrganizacion != null && !rucOrganizacion.isEmpty()) {
				sql.append("and c.organizacion.ruc = :ruc ");
				mapa.put("ruc", rucOrganizacion);
			}
	
			if (rucPersona != null && !rucPersona.isEmpty()) {
				sql.append("and c.persona.identificacion = :rucPersona ");
				mapa.put("rucPersona", rucPersona);
			}
	
			if (tipoRelacon != null && !tipoRelacon.isEmpty()) {
				sql.append("and c.tipoRelacion = :tipoRelacon ");
				mapa.put("tipoRelacon", tipoRelacon);
			}
	
			Query q = em.createQuery(sql.toString());
			for (String key : mapa.keySet()) {
				q.setParameter(key, mapa.get(key));
			}
	
			List<RelacionOrganizacion> result = q.getResultList();
			return result == null || result.isEmpty() ? null : result;
		} catch (Exception e) {
			log.info("***Error listar RelacionOrganizacion***" + e.getMessage());
			throw new GizloException("Error al listar las Factura", e);
		}
}

}
