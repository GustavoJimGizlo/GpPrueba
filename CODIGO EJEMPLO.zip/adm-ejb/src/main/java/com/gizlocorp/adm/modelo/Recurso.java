/**
 * 
 */
package com.gizlocorp.adm.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.gizlocorp.adm.enumeracion.Logico;

/**
 * 
 * @author gizloCorp
 * @version $Revision: 1.0 $
 */


@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo")
@Table(name = "tb_recurso")
public abstract class Recurso implements Serializable {

	private static final long serialVersionUID = 1L;

	/*@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)*/
	@Id
	@SequenceGenerator(name = "seq_recurso", sequenceName = "seq_recurso", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_recurso")
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(unique = true, nullable = false, length = 5)
	private String codigo;

	@Column(name = "nombre", length = 100, nullable = false)
	private String nombre;

	@Column(name = "menu", length = 1, nullable = false)
	@Enumerated(EnumType.STRING)
	private Logico menu;

	@Transient
	private boolean seleccionado;

	@Transient
	private boolean menuBol;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Logico getMenu() {
		return menu;
	}

	public void setMenu(Logico menu) {
		this.menu = menu;
	}

	public boolean isMenuBol() {
		return menuBol;
	}

	public void setMenuBol(boolean menuBol) {
		this.menuBol = menuBol;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

}
