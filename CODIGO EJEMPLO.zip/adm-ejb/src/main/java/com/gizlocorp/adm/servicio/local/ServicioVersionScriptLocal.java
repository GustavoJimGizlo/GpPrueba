/**
 * 
 */
package com.gizlocorp.adm.servicio.local;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.excepcion.GizloPersistException;
import com.gizlocorp.adm.modelo.VersionScript;

/**
 * 
 * @author
 * @version
 */
@Local
public interface ServicioVersionScriptLocal {
	List<VersionScript> listarVersion() throws GizloException;

	void ingresar(VersionScript version) throws GizloException;

	void actualizar(VersionScript version) throws GizloException;

	List<VersionScript> consultar(String esquema, Date fechaDesde,Date fechaHasta)
			throws GizloException;
	void guardar(VersionScript version) throws GizloException, GizloPersistException;
	
	void eliminar(VersionScript version) throws GizloException;
	boolean existeVersion(String esquema, Date fechaDesde,Date fechaHasta)  throws GizloException;
}
