/**
 * 
 */
package com.gizlocorp.adm.servicio.remote;

import java.util.List;

import javax.ejb.Remote;

import com.gizlocorp.adm.enumeracion.Estado;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Parametro;

/**
 * 
 * @author
 * @version
 */
@Remote
public interface ServicioParametroRemote {
	List<Parametro> listarParametros(String codigo, Estado estado,
			Long idOrganizacion) throws GizloException;

	void ingresarParametro(Parametro parametro) throws GizloException;

	void actualizarParametro(Parametro parametro) throws GizloException;

	Parametro consultarParametro(String codigo, Long idOrganizacion)
			throws GizloException;
}
