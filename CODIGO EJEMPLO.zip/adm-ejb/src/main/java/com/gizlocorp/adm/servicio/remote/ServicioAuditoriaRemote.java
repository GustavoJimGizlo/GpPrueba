/**
 * 
 */
package com.gizlocorp.adm.servicio.remote;

import javax.ejb.Remote;

/**
 * 
 * @author 
 * @version 
 */
@Remote
public interface ServicioAuditoriaRemote {

}
