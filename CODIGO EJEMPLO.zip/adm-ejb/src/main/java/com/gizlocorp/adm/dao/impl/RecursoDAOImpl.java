package com.gizlocorp.adm.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.gizlocorp.adm.dao.RecursoDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Recurso;


@Stateless
public class RecursoDAOImpl extends GenericJpaDAO<Recurso, String> implements RecursoDAO{

	
	@SuppressWarnings("unchecked")
	public List<Recurso> obtenerPorBasico(String codigo, String nombre) {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from Recurso c ");
		boolean axu=false;
		if(codigo != null && !codigo.isEmpty()){
			sql.append("where c.codigo = :codigo");
			mapa.put("codigo", codigo);
			axu = true;
		}
		
		if(nombre != null && !nombre.isEmpty()){
			if(axu){
				sql.append("and c.nombre = :nombre");
			}else{
				sql.append("where c.nombre = :nombre");				
			}
			mapa.put("nombre", nombre);
		}

		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}
		
		List<Recurso> result = q.getResultList();
		return result == null || result.isEmpty() ? null : result;
	}

	@Override
	public Recurso obtenerPorURL(String url) throws GizloException {
		try{
			StringBuilder sql = new StringBuilder();
			HashMap<String, Object> mapa = new HashMap<String, Object>();
			sql.append("select c from Recurso c where 1=1");
			
			if(url != null && !url.isEmpty()){
				sql.append(" and c.url = :url");
				mapa.put("url", url);
			}

			Query q = em.createQuery(sql.toString());
			for (String key : mapa.keySet()) {
				q.setParameter(key, mapa.get(key));
			}
			
			List<Recurso> result = q.getResultList();
			return result == null || result.isEmpty() ? null : result.get(0);
		}catch(Exception e){
			throw new GizloException("Error al obtener URL: ", e);
		}
	}

}
