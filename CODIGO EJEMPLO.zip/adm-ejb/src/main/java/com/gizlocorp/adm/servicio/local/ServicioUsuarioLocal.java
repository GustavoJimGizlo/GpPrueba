package com.gizlocorp.adm.servicio.local;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.PeticionCambio;
import com.gizlocorp.adm.modelo.Usuario;
import com.gizlocorp.adm.modelo.UsuarioExterno;

@Local
public interface ServicioUsuarioLocal {

	void guardarUsuarioExterno(UsuarioExterno usuarioExterno);

	void eliminarUsuario(UsuarioExterno usuarioExterno) throws GizloException;

	List<UsuarioExterno> obtenerParametros(String nombres, String apellidos,
			String identificacion);

	List<Usuario> obtenerUsuarioParametros(String nombres, String apellidos,
			String identificacion);

	Usuario obtenerUsuario(String username);

	UsuarioExterno obtenerUsuarioExterno(String username);

	boolean tienePermiso(String username, String url) throws GizloException;
	
	boolean registrarPeticionCambioPassword( PeticionCambio pc)throws GizloException;
	
	PeticionCambio buscarPeticion(String peticion)throws GizloException;
	
	boolean actualizarPeticionCambioPassword( PeticionCambio pc)throws GizloException;
	
}
