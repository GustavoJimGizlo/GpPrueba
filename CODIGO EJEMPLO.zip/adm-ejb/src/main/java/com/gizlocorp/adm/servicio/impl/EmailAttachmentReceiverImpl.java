package com.gizlocorp.adm.servicio.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.search.FlagTerm;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.servicio.local.EmailAttachmentReceiver;
import com.gizlocorp.adm.utilitario.DocumentUtil;
import com.gizlocorp.adm.utilitario.FechaUtil;

@Stateless
public class EmailAttachmentReceiverImpl implements EmailAttachmentReceiver {

	private static Logger log = Logger
			.getLogger(EmailAttachmentReceiverImpl.class.getName());

	/*
	 * public static void main(String arg[]) {
	 * 
	 * String host = "pop.gmail.com"; String port = "995"; String userName =
	 * "andres.giler.cadena@gmail.com"; String saveDirectory = "C:/Attachment";
	 * downloadEmailAttachments(host, port, userName, saveDirectory);
	 * 
	 * }
	 */

	/**
	 * Downloads new messages and saves attachments to disk if any.
	 * 
	 * @param host
	 * @param port
	 * @param userName
	 * @param password
	 */
	public List<String> downloadEmailAttachments(final String host,
			final String port, final String userName, final String password,
			String dirServidor, String ruc) {
		Properties properties = new Properties();

		// server setting
		properties.put("mail.pop3.host", host);
		properties.put("mail.pop3.port", port);

		// SSL setting
		properties.setProperty("mail.pop3.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		properties.setProperty("mail.pop3.socketFactory.fallback", "false");
		properties.setProperty("mail.pop3.socketFactory.port",
				String.valueOf(port));

		Folder folderInbox = null;
		Store store = null;
		List<String> documents = new ArrayList<String>();

		try {
			Session session = Session.getDefaultInstance(properties);

			store = session.getStore("pop3");
			store.connect(userName, password);

			folderInbox = store.getFolder("INBOX");
			folderInbox.open(Folder.READ_ONLY);

			Flags seen = new Flags(Flags.Flag.SEEN);
			FlagTerm unseenFlagTerm = new FlagTerm(seen, false);
			Message arrayMessages[] = folderInbox.search(unseenFlagTerm);
			String subFolder = null;

			Calendar now = Calendar.getInstance();
			String comprobante = null;

			for (int i = 0; i < arrayMessages.length; i++) {

				Message message = arrayMessages[i];
				String subject = message.getSubject();
				String contentType = message.getContentType();

				if (contentType.contains("multipart")) {
					// content may contain attachments
					Multipart multiPart = (Multipart) message.getContent();
					int numberOfParts = multiPart.getCount();
					MimeBodyPart part = null;
					for (int partCount = 0; partCount < numberOfParts; partCount++) {
						try {
							part = (MimeBodyPart) multiPart
									.getBodyPart(partCount);
							if (Part.ATTACHMENT.equalsIgnoreCase(part
									.getDisposition())
									&& (part.getFileName().contains(".xml") || part
											.getFileName().contains(".XML"))) {
								subFolder = "comprobante";

								if (subject.toLowerCase().equals("factura")) {
									subFolder = "factura";
								}
								if (subject.toLowerCase().equals("retencion")
										|| subject.toLowerCase().equals(
												"retención")) {
									subFolder = "retencion";
								}
								if (subject.toLowerCase().equals("credito")
										|| subject.toLowerCase().equals(
												"crédito")) {
									subFolder = "notaCredito";
								}
								if (subject.toLowerCase().equals("debito")
										|| subject.toLowerCase().equals(
												"débito")) {
									subFolder = "notaDebito";
								}
								if (subject.toLowerCase().equals("guia")
										|| subject.toLowerCase().equals("guía")) {
									subFolder = "guia";
								}

								// this part is attachment
								String fileName = part.getFileName();
								byte[] buffer = DocumentUtil
										.inputStreamToByte(part
												.getInputStream());

								comprobante = DocumentUtil.crearComprobante(
										buffer, FechaUtil.formatearFecha(
												now.getTime(), "dd/MM/yyyy"),
										fileName, subFolder, "recibidoManual",
										dirServidor, ruc);

								// part.saveFile(document.toString());
								documents.add(comprobante);
							}
						} catch (Exception ex) {
							log.error(ex.getMessage(), ex);
						}
					}
				}

			}

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		} finally {
			// disconnect
			if (folderInbox != null) {
				try {
					folderInbox.close(false);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}

			}
			if (store != null) {
				try {
					store.close();
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}

			}
		}

		return documents;
	}
}
