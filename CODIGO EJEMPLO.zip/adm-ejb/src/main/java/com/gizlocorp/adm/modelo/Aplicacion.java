package com.gizlocorp.adm.modelo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.gizlocorp.adm.utilitario.Constantes;


@Entity
@DiscriminatorValue(Constantes.RECURSO_APLICACION)
public class Aplicacion extends Recurso {

	private static final long serialVersionUID = 1L;

}
