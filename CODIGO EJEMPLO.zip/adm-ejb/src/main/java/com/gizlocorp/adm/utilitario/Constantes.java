/**
 * 
 */
package com.gizlocorp.adm.utilitario;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 
 * @author
 * @version $Revision: 1.0 $
 */
public class Constantes {

	public static final String DIRECTORIO_BACKUP_PRODUCCION = "/u03/back_gnvoice/comprobantes/";
	public static final String USUARIO_INTERNO = "INT";
	public static final String USUARIO_EXTERNO = "EXT";
	
	public static final String RECURSO_APLICACION = "APP";
	public static final String RECURSO_MODULO = "MOD";

	public static final String LDAP_PROVIDER = "ldap.provider";
	public static final String LDAP_SECURITY_AUTHENTICATION = "ldap.security.authentication";
	public static final String LDAP_PRINCIPAL_DOMAIN = "ldap.principal.domain";
	public static final String LDAP_USER = "ldap.user";
	public static final String LDAP_PASSWORD = "ldap.password";
	public static final String CARACTER_ESPECIAL = ",";
	public static final String LDAP_BASE_GENERAL = "OU=PROVINCIAS,DC=fj,DC=local";
	public static final String LDAP_BASE_OU = "OU=";
	public static final String LDAP_BASE_USUARIOS = "OU=Internos,OU=Usuarios";
	public static final String LDAP_EXCEDE_RESULTADOS = "Los resultados de la busqueda exceden el limite, por favor agregar otro parametro de busqueda";
	public static final String LDAP_NO_RESULTADOS = "No se encontraron resultados, verifique los parametros de busqueda";
	public static final String LDAP_PARAMETRO_ORDENAR = "cn";
	public static final String LDAP_PAIS_PRINCIPAL = "ECUADOR";

	public static final String ENCRYPT_PASSWORD = "encrypt.password";
	public static final String ENCRYPT_TOLERANCE = "encrypt.token.tolerance";

	private static final String[] ENABLED_USER_ACCOUNT = { "512", "544", "66048", "66080", "262656", "262688", "328192",
			"328224" };

	public static final int LDAP_PAGES = 20;

	public static final String CLIENT_USER = "adm-remote.user";
	public static final String CLIENT_PASSWORD = "adm-remote.password";
	public static final String CLIENT_URL_PROVIDER = "adm.remote.provider";
	public static final String CLIENT_MODULO = "adm.modulo";

	public static final String GENERO = "genero";
	public static final String CODIGO_GENERO = "C23";

	public static final String ESTADO_CIVIL = "Estado Civil";
	public static final String CODIGO_ESTADO_CIVIL = "C24";

	public static final String TIPO_IDENTIFICACION = "Tipo Identificacion";
	public static final String CODIGO_TIPO_IDENTIFICACION = "C25";

	public static final String CODIGO_EVENTO = "EVENT";

	public static final String MODO_ONLINE = "ONLINE";
	public static final String MODO_OFFLINE = "OFFLINE";

	public static final String VERSION_ONLINE = "online/1_10";
	public static final String VERSION_OFFLINE = "offline/2_10";
	
	public static final String SITE_KEY ="6LcRhzkUAAAAAOiCojnc140LgptaRnalJNUML6mH";
	public static final String SECRET_KEY ="6LcRhzkUAAAAAFBypYwBs8MF2UO2wyx_Scdf7Aca";

	public static List<String> getEnabledUserAccount() {
		return Collections.unmodifiableList(Arrays.asList(ENABLED_USER_ACCOUNT));
	}

}
