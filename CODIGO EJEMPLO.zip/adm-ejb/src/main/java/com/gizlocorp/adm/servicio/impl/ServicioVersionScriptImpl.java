/**
 * 
 */
package com.gizlocorp.adm.servicio.impl;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.dao.VersionScriptDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.excepcion.GizloPersistException;
import com.gizlocorp.adm.modelo.VersionScript;
import com.gizlocorp.adm.servicio.local.ServicioVersionScriptLocal;

/**
 * 
 * @author
 * @version
 */
@Stateless
public class ServicioVersionScriptImpl implements ServicioVersionScriptLocal {

	private static Logger log = Logger.getLogger(ServicioVersionScriptImpl.class
			.getName());
	@EJB
	VersionScriptDAO scriptDAO;


	@Override
	public List<VersionScript> listarVersion() throws GizloException {
		return scriptDAO.findAll();
	}
	@Override
	public void ingresar(VersionScript version) throws GizloException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actualizar(VersionScript version) throws GizloException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<VersionScript> consultar(String esquema, Date fechaDesde, Date fechaHasta)
			throws GizloException {
		
		return scriptDAO.consultar(esquema, fechaDesde, fechaHasta);
	}
	@Override
	public void guardar(VersionScript version) throws GizloException, GizloPersistException {

		scriptDAO.persist(version);
		
	}
	@Override
	public boolean existeVersion(String esquema, Date fechaDesde,
			Date fechaHasta) throws GizloException {
		return scriptDAO.existeVersion(esquema, fechaDesde, fechaHasta);
	}
	@Override
	public void eliminar(VersionScript version) throws GizloException {
		// TODO Auto-generated method stub
		
	}

	
}
