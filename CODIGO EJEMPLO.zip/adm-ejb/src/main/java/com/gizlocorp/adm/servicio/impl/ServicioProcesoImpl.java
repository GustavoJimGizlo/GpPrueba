package com.gizlocorp.adm.servicio.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.gizlocorp.adm.dao.ProcesoDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Proceso;
import com.gizlocorp.adm.servicio.local.ServicioProcesoLocal;

@Stateless
public class ServicioProcesoImpl implements ServicioProcesoLocal {

	@EJB
	ProcesoDAO procesoDAO;

	@Override
	public void guardarProceso(Proceso proceso) {
		
			try {
				if(proceso.getId() == null){
					procesoDAO.persist(proceso);
				}else{
					procesoDAO.update(proceso);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		
	}

	@Override
	public void eliminarProceso(Proceso proceso) throws GizloException {
				
	}

	@Override
	public List<Proceso> obtenerProcesos(String tipo, String nombre) {
		
		return procesoDAO.obtenerProcesos(tipo, nombre);
	}
	

	
}
