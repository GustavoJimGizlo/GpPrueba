package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.RelacionOrganizacion;

@Local
public interface RelacionOrganizacionDAO extends
		GenericDAO<RelacionOrganizacion, Long> {

	List<RelacionOrganizacion> buscarPorParametros(String ruc, String nombre,
			String tipoRelacon) throws GizloException;

	boolean existeRelacionOrganizacion(String ruc, String rucRelacion,
			String tipoRelacion) throws GizloException;
	
	List<RelacionOrganizacion> buscarPorParametrosAll(String rucOrganizacion, String rucPersona, String tipoRelacon) throws GizloException;

}
