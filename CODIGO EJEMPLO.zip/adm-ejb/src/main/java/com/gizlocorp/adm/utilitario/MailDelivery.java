package com.gizlocorp.adm.utilitario;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.excepcion.MessageNotSentException;

public class MailDelivery {

	private static Logger log = Logger.getLogger(MailDelivery.class.getName());

	public static void main(String[] args) {
		// final String username = "documentoelectronicocomreivic";
		// final String password = "facturac2014";

		Properties props = new Properties();
		props.put("mail.smtp.host", "192.168.1.248");
		// props.put("mail.smtp.socketFactory.port", "25");
		// props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		// props.put("mail.smtp.auth", "false");
		// props.put("mail.smtp.port", "25");

		MailMessage mailMensaje = new MailMessage();
		mailMensaje.setSubject("prueba gms");
		mailMensaje.setFrom("mega.factelectronica@mega-santamaria.com");
		mailMensaje.setTo(Arrays.asList("jose.vinueza@gizlocorp.com"));
		mailMensaje.setBody("No se a podido conectar con el servidor de archivos");
		try {
			MailDelivery.send(mailMensaje, "192.168.1.248", "587", "mega.factelectronica@mega-santamaria.com",
					"sistemas2014");

			// MailDelivery
			// .send(mailMensaje,"smtp.gmail.com","465","josevinueza87@gmail.com","JoseVinueza872");
		} catch (MessageNotSentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		/*
		 * Session session = Session.getDefaultInstance(props, new
		 * javax.mail.Authenticator() { protected PasswordAuthentication
		 * getPasswordAuthentication() { return new PasswordAuthentication(username,
		 * password); } });
		 */
		// Session session = Session.getInstance(props, null);
		//
		// try {
		//
		// Message message = new MimeMessage(session);
		// message.setFrom(new InternetAddress(
		// "facturacionGPF@corporaciongpf.com"));
		// message.setRecipients(Message.RecipientType.TO,
		// InternetAddress.parse("carla.salvatierra@gizlocorp.com"));
		// message.setSubject("Testing Subject");
		// message.setText("Dear Mail Crawler,"
		// + "\n\n No spam to my email, please!");
		//
		// Transport.send(message);
		//
		// } catch (MessagingException e) {
		// throw new RuntimeException(e);
		// }
	}

	public static void send(final DeliveryMessage mailMessage, final String smtpHost, final String smtpPort,
			final String smtpUsername, final String smtpPassword) throws MessageNotSentException {

		// envioCorreo();

		if (!(mailMessage instanceof MailMessage)) {
			throw new MessageNotSentException("El mensaje no es de tipo mail");
		}

		try {
			Properties props = new Properties();
			props.put("mail.smtp.host", smtpHost);
			// props.put("mail.smtp.socketFactory.port", "25");

			// props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", smtpPort);

			Session session = null;
			if (smtpPassword != null && !smtpPassword.isEmpty()) {
				props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				props.put("mail.smtp.auth", "true");
				session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(smtpUsername, smtpPassword);
					}
				});
			} else {
				props.put("mail.smtp.auth", "false");
				session = Session.getInstance(props, null);
			}

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(mailMessage.getFrom()));

			StringBuilder recipients = new StringBuilder();
			// recipients.append("andres.giler@gizlocorp.com,");

			if (mailMessage.getTo() != null && !mailMessage.getTo().isEmpty()) {
				int counter = 1;
				for (String to : mailMessage.getTo()) {
					recipients.append(to);
					if (counter != mailMessage.getTo().size()) {
						recipients.append(",");
					}
					counter++;

				}
			}

			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipients.toString()));
			message.setSubject(mailMessage.getSubject());

			MailMessage mm = (MailMessage) mailMessage;
			prepareMessage(mm, message);

			Transport.send(message);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new MessageNotSentException(e);
		}

	}

	/**
	 * Prepara el mensaje a ser enviado por correo electronico
	 * 
	 * @param mailMessage
	 * @param session
	 * @return mensaje
	 * @throws MessagingException
	 * @throws IOException
	 */
	private static void prepareMessage(final MailMessage mailMessage, final Message message)
			throws MessagingException, IOException {
		message.setSentDate(new Date());

		// email message text.
		MimeBodyPart messagePart = new MimeBodyPart();
		// messagePart.setText(mailMessage.getBody());
		// BodyPart bodyHtml = new MimeBodyPart();
		messagePart.setContent(mailMessage.getBody(), "text/html");

		// email attachment file
		MimeBodyPart attachmentPart = null, attachmentPDFPart = null;
		if (mailMessage.getAttachment() != null && !mailMessage.getAttachment().isEmpty()) {

			if (mailMessage.getAttachment().get(0) != null && !mailMessage.getAttachment().get(0).contains("null")) {
				FileDataSource fileDataSource = new FileDataSource(mailMessage.getAttachment().get(0)) {

					@Override
					public String getContentType() {
						return "text/xml";
					}
				};

				String[] fileNameXml = mailMessage.getAttachment().get(0).split("/");
				attachmentPart = new MimeBodyPart();
				attachmentPart.setDataHandler(new DataHandler(fileDataSource));
				attachmentPart.setFileName(fileNameXml[fileNameXml.length - 1]);
			}

			// PDF part

			
			if (mailMessage.getPdf() != null) {

				attachmentPDFPart = new MimeBodyPart();

				DataSource filePDFDataSource = new ByteArrayDataSource(mailMessage.getPdf().getBytes(), "application/pdf");
				attachmentPDFPart.setDataHandler(new DataHandler(filePDFDataSource));
				attachmentPDFPart.setFileName(mailMessage.getPdf().getNombre()+"."+mailMessage.getPdf().getExtension());

			}
		}

		Multipart multipart = new MimeMultipart();
		// multipart.addBodyPart(bodyHtml);

		if (messagePart != null) {
			multipart.addBodyPart(messagePart);
		}
		if (attachmentPart != null) {
			multipart.addBodyPart(attachmentPart);
		}
		if (attachmentPDFPart != null) {
			multipart.addBodyPart(attachmentPDFPart);
		}
		message.setContent(multipart);

	}
}
