/**
 * 
 */
package com.gizlocorp.adm.servicio.remote;

import java.io.IOException;

import javax.ejb.Remote;

/**
 * 
 * @author
 * @version
 */
@Remote
public interface ServicioDocumentoRemote {

	String crearComprobante(String xmlSource, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws IOException;

	String crearComprobante(byte[] xml, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws Exception;
}
