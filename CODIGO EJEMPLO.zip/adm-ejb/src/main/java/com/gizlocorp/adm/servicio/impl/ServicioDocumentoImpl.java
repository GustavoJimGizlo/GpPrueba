package com.gizlocorp.adm.servicio.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.servicio.local.ServicioDocumentoLocal;

@Stateless
public class ServicioDocumentoImpl implements ServicioDocumentoLocal {

	public static final Logger log = Logger
			.getLogger(ServicioDocumentoImpl.class);

	// private static final Store STORE = new Store("workspace", "SpacesSt	re");

	public String crearComprobante(String xmlSource, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws IOException {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/comprobantes/");
		pathFolder.append(comprobante);
		pathFolder.append("/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");

		if (fechaEmision.contains("/")) {
			fechaEmision = fechaEmision.replace("/", "");
		} else if (fechaEmision.contains("-")) {
			fechaEmision = fechaEmision.replace("-", "");
		}

		pathFolder.append(fechaEmision);
		pathFolder.append("/");

		// log.debug("folder: " + pathFolder);
		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);

		pathFile.append(".xml");
		stringToFile(xmlSource, pathFile.toString());

		return pathFile.toString();
	}

	public String crearComprobante(byte[] xml, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws Exception {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/comprobantes/");
		pathFolder.append(comprobante);
		pathFolder.append("/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");

		if (fechaEmision.contains("/")) {
			fechaEmision = fechaEmision.replace("/", "");
		} else if (fechaEmision.contains("-")) {
			fechaEmision = fechaEmision.replace("-", "");
		}

		pathFolder.append(fechaEmision);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);

		pathFile.append(".xml");

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(xml);
		fos.close();

		return pathFile.toString();
	}

	/**
	 * @param path
	 * @return
	 * @throws FileNotFoundException
	 */
	private void createDirectory(String path) throws FileNotFoundException {
		StringBuffer pathname = new StringBuffer(path);

		if (!path.trim().endsWith("/")) {
			pathname.append("/");
		}
		// log.debug("Directorio URL: " + pathname.toString());
		File directory = new File(pathname.toString());
		// //log.debug(pathname.toString());
		if (!directory.exists()) {
			if (!directory.mkdirs()) {
				throw new FileNotFoundException();
			}
		}
	}

	private void stringToFile(String xmlSource, String fileName)
			throws IOException {
		java.io.FileWriter fw = new java.io.FileWriter(fileName);
		fw.write(xmlSource);
		fw.close();
	}

}
