package com.gizlocorp.adm.servicio.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.gizlocorp.adm.dao.HomologarMensajesDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.excepcion.GizloPersistException;
import com.gizlocorp.adm.excepcion.GizloUpdateException;
import com.gizlocorp.adm.modelo.HomologarMensaje;
import com.gizlocorp.adm.servicio.local.ServicioHomologarLocal;

@Stateless
public class ServicioHomologarImpl implements ServicioHomologarLocal {

	@EJB
	HomologarMensajesDAO homologarMensajesDAO;

	@Override
	public List<HomologarMensaje> obtenerMensajes(String nombre, String errorAplicacion)  {
		
		try {
			return homologarMensajesDAO.obtenerMensajes(nombre, errorAplicacion);
		} catch (GizloException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void guardar(HomologarMensaje homologarMensaje) throws GizloException {
		if(homologarMensaje.getId() == null){
			try {
				homologarMensajesDAO.persist(homologarMensaje);
			} catch (GizloPersistException e) {
				e.printStackTrace();
			}
		}else{
			try {
				homologarMensajesDAO.update(homologarMensaje);
			} catch (GizloUpdateException e) {
				e.printStackTrace();
			}
		}
		
	}
	

	
}
