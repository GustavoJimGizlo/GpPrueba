/**
 * 
 */
package com.gizlocorp.adm.servicio.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.dao.RelacionOrganizacionDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.excepcion.GizloPersistException;
import com.gizlocorp.adm.excepcion.GizloUpdateException;
import com.gizlocorp.adm.modelo.RelacionOrganizacion;
import com.gizlocorp.adm.servicio.local.ServicioRelacionOrganizacionLocal;

/**
 * 
 * @author
 * @version
 */
@Stateless
public class ServicioRelacionOrganizacionImpl implements
		ServicioRelacionOrganizacionLocal {

	// private static Logger log =
	// Logger.getLogger(ServicioRelacionOrganizacionImpl.class.getName());
	@EJB
	RelacionOrganizacionDAO relacionOrganizacionDAO;

	public static final Logger log = Logger
			.getLogger(ServicioRelacionOrganizacionImpl.class);

	@Override
	public void guardarRelacionOrganizacion(
			RelacionOrganizacion relacionOrganizacion) throws GizloException {

		try {
			boolean existeRelacion = relacionOrganizacionDAO
					.existeRelacionOrganizacion(relacionOrganizacion
							.getOrganizacion().getRuc(), relacionOrganizacion
							.getOrganizacionRelacion().getRuc(),
							relacionOrganizacion.getTipoRelacion());

			if (existeRelacion) {
				try {
					relacionOrganizacionDAO.update(relacionOrganizacion);
				} catch (GizloUpdateException e) {
					throw new GizloException(e);
				}
				return;
			}
		} catch (GizloException e) {
			log.error("Error en busqueda relacion organizacion", e);
		}

		if (relacionOrganizacion.getId() != null) {
			try {
				relacionOrganizacionDAO.update(relacionOrganizacion);
			} catch (GizloUpdateException e) {
				throw new GizloException(e);
			}
		} else {
			try {
				relacionOrganizacionDAO.persist(relacionOrganizacion);
			} catch (GizloPersistException e) {
				throw new GizloException(e);
			}
		}

	}

	@Override
	public List<RelacionOrganizacion> buscarPorParametros(String ruc,
			String nombre, String tipoRelacon) throws GizloException {
		return relacionOrganizacionDAO.buscarPorParametros(ruc, nombre,
				tipoRelacon);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public RelacionOrganizacion buscarPorParametrosAll(
			String rucOrganizacion, String rucPersona, String tipoRelacon)
			throws GizloException {
		List<RelacionOrganizacion> lista = relacionOrganizacionDAO.buscarPorParametrosAll(rucOrganizacion, rucPersona, tipoRelacon);
		if(lista != null && !lista.isEmpty()){
			return lista.get(0);
		}else{
			return null;
		}
		
		
	}

}
