package com.gizlocorp.adm.servicio.local;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Proceso;

@Local
public interface ServicioProcesoLocal {

	void guardarProceso(Proceso proceso);

	void eliminarProceso(Proceso proceso) throws GizloException;

	List<Proceso> obtenerProcesos(String tipo, String nombre);

	

}
