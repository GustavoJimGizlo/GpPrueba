package com.gizlocorp.adm.dao.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.gizlocorp.adm.dao.ProcesoDAO;
import com.gizlocorp.adm.modelo.Proceso;
import com.gizlocorp.adm.utilitario.MailDelivery;
import com.gizlocorp.adm.utilitario.MailMessage;
import com.gizlocorp.adm.utilitario.PropertiesUtil;

/**
 * @author 
 * 
 */

@Stateless
public class ProcesoDAOImpl extends GenericJpaDAO<Proceso, Long> implements
		ProcesoDAO {
	 private static Logger log = Logger.getLogger(ProcesoDAOImpl.class.getName());
	@SuppressWarnings("unchecked")
	@Override
	public List<Proceso> obtenerProcesos(String tipo, String nombre) {
		log.info("obtener procesos");
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select p from Proceso p where 1=1");

		if (tipo != null && !tipo.isEmpty()) {
			sql.append("and p.tipo = :tipo ");
			mapa.put("tipo", tipo);
		}
		log.info("paso primer if");
		if (nombre != null && !nombre.isEmpty()) {
			sql.append("and p.nombre = :nombre ");
			mapa.put("nombre", nombre);
		}
		log.info("paso segundo if");

		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}
		log.info("paso primer for");
		List<Proceso> result = null;

		try{
			result = q.getResultList();
			log.info("carga result: "+result);
		}catch(Exception ex){
			
			if (ex != null
					&& ex.getMessage() != null
					&& (ex.getMessage().contains("No space left on device")
							|| ex.getMessage().contains(
									"JDBCConnectionException")
							|| ex.getMessage().contains(
									"SQLRecoverableException") || ex
							.getMessage().contains("Could not open connection"))) {
				try {
					log.info("hubo error:"+ex.getMessage());
					PropertiesUtil prop = PropertiesUtil.getInstance("");
					MailMessage mailMensaje = new MailMessage();
					mailMensaje.setSubject("Ha ocurrido un error");
					mailMensaje.setFrom(prop.getCorreoRemite());
					mailMensaje.setTo(Arrays.asList(prop.getCorreoAdmin()));
					mailMensaje.setBody("Alerta " + this.getClass() + ": "
							+ ex.getMessage());
					MailDelivery.send(mailMensaje, prop.getSmtpHost(),
							prop.getSmtpPort(), prop.getSmtpUsername(),
							prop.getSmtpPassword());
				} catch (Exception e2) {
				}
			}
		}
		
		log.info("procesos"+result);
		return result == null || result.isEmpty() ? null : result;
	}

	

}
