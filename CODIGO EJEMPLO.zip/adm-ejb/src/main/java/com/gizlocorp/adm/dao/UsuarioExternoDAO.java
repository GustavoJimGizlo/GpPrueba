package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.modelo.UsuarioExterno;

@Local
public interface UsuarioExternoDAO extends GenericDAO<UsuarioExterno, String>{
	
	public List<UsuarioExterno> obtenerParametros(String nombres, String apellidos, String identificacion);
	
	public UsuarioExterno obtenerUsuarioExterno(String username);

}
