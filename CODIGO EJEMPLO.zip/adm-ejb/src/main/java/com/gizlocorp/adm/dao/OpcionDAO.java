package com.gizlocorp.adm.dao;

import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.modelo.Modulo;
import com.gizlocorp.adm.modelo.Opcion;
import com.gizlocorp.adm.modelo.Rol;

@Local
public interface OpcionDAO extends GenericDAO<Opcion, String>{
	
	Opcion recuperar(String codigo, String nombre);
	
	List<Opcion> buscarPorRolModulo(Rol rol, Modulo modulo);

}
