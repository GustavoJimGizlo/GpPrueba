package com.gizlocorp.adm.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.gizlocorp.adm.dao.OpcionDAO;
import com.gizlocorp.adm.modelo.Modulo;
import com.gizlocorp.adm.modelo.Opcion;
import com.gizlocorp.adm.modelo.Rol;

@Stateless
public class OpcionDAOImpl extends GenericJpaDAO<Opcion, String> implements OpcionDAO {

	@Override
	public Opcion recuperar(String codigo, String nombre) {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from Opcion c ");
		boolean aux=false;
		if(codigo != null && !codigo.isEmpty()){
			sql.append("where c.codigo = :codigo");
			mapa.put("codigo", codigo);
			aux = true;
		}
		
		if(nombre != null && !nombre.isEmpty()){
			if(aux)
				sql.append("and c.nombre like :nombre");
			else
				sql.append("where c.nombre like :nombre");
			mapa.put("nombre", "%" + nombre + "%");
		}
		
		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}
		
		return (q.getResultList() != null && !q.getResultList().isEmpty()) ? (Opcion) q.getResultList().get(0) : null;
	}

	@SuppressWarnings("unchecked")
	public List<Opcion> buscarPorRolModulo(Rol rol, Modulo modulo) {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from Opcion c ");
		boolean aux=false;
		if(rol != null){
			sql.append("where c.rol = :rol");
			mapa.put("rol", rol);
			aux = true;
		}
		
		if(modulo != null ){
			if(aux)
				sql.append(" and c.modulo = :modulo");
			else
				sql.append("where c.modulo = :modulo");
			mapa.put("modulo",  modulo);
		}
		
		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}		
		List<Opcion> result = q.getResultList();
		return result == null || result.isEmpty() ? null : result;
	}

}
