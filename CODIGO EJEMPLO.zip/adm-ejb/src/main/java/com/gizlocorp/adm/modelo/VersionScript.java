package com.gizlocorp.adm.modelo;

import java.io.Serializable;
import java.lang.Long;
import java.lang.String;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: VersionScript
 *
 */
@Entity
@Table(name = "tb_version_script")
public class VersionScript implements Serializable {

	@Id
	@SequenceGenerator(name = "seq_version_script", sequenceName = "seq_version_script", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_version_script")
	private Long id;
	private String tipoEsquema;
	private String rutaXsd;
	private String rutaPdf;
	private static final long serialVersionUID = 1L;
	@Temporal(TemporalType.DATE)
	private Date fechaDesde;
	@Temporal(TemporalType.DATE)
	private Date fechaHasta;
	
	public VersionScript() {
		super();
	}   
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}   
	public String getTipoEsquema() {
		return this.tipoEsquema;
	}

	public void setTipoEsquema(String tipoEsquema) {
		this.tipoEsquema = tipoEsquema;
	}   
	public String getRutaXsd() {
		return this.rutaXsd;
	}

	public void setRutaXsd(String rutaXsd) {
		this.rutaXsd = rutaXsd;
	}   
	public String getRutaPdf() {
		return this.rutaPdf;
	}

	public void setRutaPdf(String rutaPdf) {
		this.rutaPdf = rutaPdf;
	}
	public Date getFechaDesde() {
		return fechaDesde;
	}
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	public Date getFechaHasta() {
		return fechaHasta;
	}
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
}
