package com.gizlocorp.adm.servicio.local;

import java.util.List;

import javax.ejb.Local;

@Local
public interface EmailAttachmentReceiver {

	List<String> downloadEmailAttachments(final String host, final String port,
			final String userName, final String password, String dirServidor, String ruc);
}
