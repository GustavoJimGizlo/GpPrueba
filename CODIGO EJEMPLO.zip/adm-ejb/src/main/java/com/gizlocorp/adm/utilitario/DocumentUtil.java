package com.gizlocorp.adm.utilitario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

//log4j.//logger;
import com.gizlocorp.adm.excepcion.FileException;

public class DocumentUtil {
	public static final Logger log = Logger.getLogger(DocumentUtil.class);

	// private static final Store STORE = new Store("workspace", "SpacesSt	re");

	public static String crearComprobante(String xmlSource,
			String fechaEmision, String claveAcceso, String comprobante,
			String subcarpeta, String dirAlmacenamiento, String ruc) throws IOException, ParseException {
		StringBuilder pathFolder = new StringBuilder();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(simpleDateFormat.parse(fechaEmision));
		pathFolder.append(dirAlmacenamiento);//facturas/emisores/emisor
		pathFolder.append("/");
		pathFolder.append(comprobante);//facturas/emisores/emisor/comprobante/
		pathFolder.append("/");
		pathFolder.append(subcarpeta);//facturas/emisores/emisor/comprobante/estado/
		pathFolder.append("/");
		pathFolder.append(calendar.get(Calendar.YEAR));//facturas/emisores/emisor/comprobante/estado/anio
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.MONTH) + 1));//facturas/emisores/emisor/comprobante/estado/anio/mes
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.DAY_OF_MONTH)));//facturas/emisores/emisor/comprobante/estado/anio/mes/dia
		pathFolder.append("/");

		// log.debug("folder: " + pathFolder);
		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);

		pathFile.append(".xml");
		stringToFile(xmlSource, pathFile.toString());
		return pathFile.toString();
	}
	
	public static void main(String...args) throws ParseException  {
		StringBuilder pathFolder = new StringBuilder();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(simpleDateFormat.parse("09/09/2018"));
		pathFolder.append("/facturas/emisores/emisor");//facturas/emisores/emisor
		pathFolder.append("/");
		pathFolder.append("factura");//facturas/emisores/emisor/comprobante/
		pathFolder.append("/");
		pathFolder.append("autorizado");//facturas/emisores/emisor/comprobante/estado/
		pathFolder.append("/");
		pathFolder.append(calendar.get(Calendar.YEAR));//facturas/emisores/emisor/comprobante/estado/anio
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.MONTH) + 1));//facturas/emisores/emisor/comprobante/estado/anio/mes
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.DAY_OF_MONTH)));//facturas/emisores/emisor/comprobante/estado/anio/mes/dia
		pathFolder.append("/");
		System.out.println(pathFolder.toString());
	}

	private static String agregarCeros(int valor) {
		StringBuilder string = new StringBuilder();
		if(valor < 10) {	
			string.append("0");
			string.append(valor);
			return string.toString();
		}
		return String.valueOf(valor);		
	}

	public static String crearComprobante(byte[] xml, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String directorioComprobantes, String ruc) throws Exception {
		/*StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/comprobantes/");
		pathFolder.append(ruc);
		pathFolder.append("/");
		//pathFolder.append("C:\\Users\\Usuario\\Desktop\\xmlprueba\\pruebarecibido\\");
		pathFolder.append(comprobante);
		pathFolder.append("/");
		//pathFolder.append("\\");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");
		//pathFolder.append("\\");

		if (fechaEmision.contains("/")) {
			fechaEmision = fechaEmision.replace("/", "");
		} else if (fechaEmision.contains("-")) {
			fechaEmision = fechaEmision.replace("-", "");
		}

		pathFolder.append(fechaEmision);
		pathFolder.append("/");
		//pathFolder.append("\\");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);

		if(!pathFile.toString().toLowerCase().contains(".xml")){
			pathFile.append(".xml");
		}
		*/
		StringBuilder pathFolder = new StringBuilder();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(simpleDateFormat.parse(fechaEmision));
		pathFolder.append(directorioComprobantes);//facturas/emisores/emisor
		pathFolder.append("/");
		pathFolder.append(comprobante);//facturas/emisores/emisor/comprobante/
		pathFolder.append("/");
		pathFolder.append(subcarpeta);//facturas/emisores/emisor/comprobante/estado/
		pathFolder.append("/");
		pathFolder.append(calendar.get(Calendar.YEAR));//facturas/emisores/emisor/comprobante/estado/anio
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.MONTH) + 1));//facturas/emisores/emisor/comprobante/estado/anio/mes
		pathFolder.append("/");
		pathFolder.append(agregarCeros(calendar.get(Calendar.DAY_OF_MONTH)));//facturas/emisores/emisor/comprobante/estado/anio/mes/dia
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);
		pathFile.append(".xml");
		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(xml);
		fos.close();

		return pathFile.toString();
	}
	
	public static String crearComprobantePdf(byte[] pdf, String fechaEmision,
			String claveAcceso, String comprobante, String subcarpeta,
			String dirServidor) throws Exception {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/comprobantes/");
		pathFolder.append(comprobante);
		pathFolder.append("/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");

		if (fechaEmision.contains("/")) {
			fechaEmision = fechaEmision.replace("/", "");
		} else if (fechaEmision.contains("-")) {
			fechaEmision = fechaEmision.replace("-", "");
		}

		pathFolder.append(fechaEmision);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(claveAcceso);

		pathFile.append(".pdf");

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(pdf);
		fos.close();

		return pathFile.toString();
	}

	public static String createDocumentText(byte[] archivo,
			String nombreArchivo, String identificador, String subcarpeta,
			String dirServidor) throws IOException {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/claves/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");
		pathFolder.append(identificador);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(nombreArchivo);

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(archivo);
		fos.close();

		return pathFile.toString();
	}

	public static String createDocumentImage(byte[] archivo,
			String nombreArchivo, String identificador, String subcarpeta,
			String dirServidor) throws IOException {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/imagenes/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");
		pathFolder.append(identificador);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(nombreArchivo);

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(archivo);
		fos.close();

		return pathFile.toString();
	}

	public static String createDocumentToken(byte[] archivo,
			String nombreArchivo, String identificador, String subcarpeta,
			String dirServidor) throws IOException {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/firmaelectronica/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");
		pathFolder.append(identificador);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(nombreArchivo);

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(archivo);
		fos.close();

		return pathFile.toString();
	}

	public static String createDocumentlogo(byte[] archivo,
			String nombreArchivo, String identificador, String subcarpeta,
			String dirServidor) throws IOException {
		StringBuilder pathFolder = new StringBuilder();

		pathFolder.append(dirServidor);
		pathFolder.append("/gnvoice/recursos/imagenes/");
		pathFolder.append(subcarpeta);
		pathFolder.append("/");
		pathFolder.append(identificador);
		pathFolder.append("/");

		createDirectory(pathFolder.toString());

		StringBuilder pathFile = new StringBuilder();
		pathFile.append(pathFolder.toString());
		pathFile.append(nombreArchivo);

		FileOutputStream fos = new FileOutputStream(pathFile.toString());
		fos.write(archivo);
		fos.close();

		return pathFile.toString();
	}

	/**
	 * @param path
	 * @return
	 * @throws FileNotFoundException
	 */
	public static void createDirectory(String path)
			throws FileNotFoundException {
		StringBuffer pathname = new StringBuffer(path);

		if (!path.trim().endsWith("/")) {
			pathname.append("/");
		}
		// log.debug("Directorio URL: " + pathname.toString());
		File directory = new File(pathname.toString());
		// //log.debug(pathname.toString());
		if (!directory.exists()) {
			if (!directory.mkdirs()) {
				throw new FileNotFoundException();
			}
		}
	}

	/**
	 * @param filePath
	 * @return
	 * @throws FileException
	 */
	public static String readContentFile(String filePath) throws FileException {
		try {
			File file = new File(filePath);
			String content = org.apache.commons.io.FileUtils
					.readFileToString(file);

			return content;

		} catch (IOException e) {
			throw new FileException(e);
		}
	}

	/**
	 * @param filePath
	 * @return
	 * @throws FileException
	 */
	public static byte[] readFile(String filePath) throws FileException {
		try {
			File file = new File(filePath);
			byte[] content = org.apache.commons.io.FileUtils
					.readFileToByteArray(file);
			return content;

		} catch (IOException e) {
			throw new FileException(e);
		}
	}

	/**
	 * Transforma un archivo (File) a bytes
	 * 
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public static byte[] fileoByte(File file) throws IOException {

		byte[] buffer = new byte[(int) file.length()];
		InputStream ios = null;
		try {
			ios = new FileInputStream(file);
			if (ios.read(buffer) == -1) {
				throw new IOException(
						"EOF reached while trying to read the whole file");
			}
		} finally {
			try {
				if (ios != null) {
					ios.close();
				}
			} catch (IOException e) {
				//
			}
		}

		return buffer;
	}

	/**
	 * Transforma un archivo (File) a bytes
	 * 
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public static byte[] inputStreamToByte(InputStream ios) throws IOException {

		byte[] buffer = new byte[(int) 4096];
		try {
			if (ios.read(buffer) == -1) {
				throw new IOException(
						"EOF reached while trying to read the whole file");
			}
		} finally {
			try {
				if (ios != null) {
					ios.close();
				}
			} catch (IOException e) {
				//
			}
		}

		return buffer;
	}

	private static void stringToFile(String xmlSource, String fileName)
			throws IOException {
		java.io.FileWriter fw = new java.io.FileWriter(fileName);
		fw.write(xmlSource);
		fw.close();
	}
	

}
