/**
 * 
 */
package com.gizlocorp.adm.servicio.remote;

import java.util.List;

import javax.ejb.Remote;

import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.UbicacionGeografica;



/**
 * 
 * @author 
 * @version 
 */
@Remote
public interface ServicioUbicacionGeograficaRemote {
	List<UbicacionGeografica> listarCiudades(Long idProvincia) throws GizloException;
	List<UbicacionGeografica> listarCiudades() throws GizloException;
}
