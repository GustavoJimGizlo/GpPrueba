package com.gizlocorp.adm.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "tb_proceso")
public class Proceso {
	
	@Id
	@SequenceGenerator(name = "seq_proceso", sequenceName = "seq_proceso", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_proceso")
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "condicion", length = 250)
	private String condicion;

	@Column(name = "tipo", length = 50)
	private String tipo;
	
	@Column(name = "nombre", length = 250)
	private String nombre;
	
	@Column(name = "descripcion", length = 250)
	private String descripcion;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCondicion() {
		return condicion;
	}

	public void setCondicion(String condicion) {
		this.condicion = condicion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
