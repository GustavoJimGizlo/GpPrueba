/*
 * OfertaDao.java
 * 
 * Copyright (c) 2012 FARCOMED.
 * Todos los derechos reservados.
 */

package com.gizlocorp.adm.dao.impl;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.gizlocorp.adm.dao.VersionScriptDAO;
import com.gizlocorp.adm.enumeracion.ModoEnvio;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.VersionScript;

/**
 * Clase
 * 
 * @author gizlo
 * @revision $Revision: 1.7 $
 */
@Stateless
public class VersionScriptDAOImpl extends GenericJpaDAO<VersionScript, Long>
		implements VersionScriptDAO {

	@Override
	public List<VersionScript> cargarRuta(ModoEnvio modoEnvio) {
		try {
			StringBuilder hqls = new StringBuilder(
					"select t from VersionScript t where t.tipoEsquema = :tipoEsquema and CURRENT_DATE >=t.fechaDesde  and (t.fechaHasta is null or  CURRENT_DATE <= t.fechaHasta)");

			Query q = em.createQuery(hqls.toString());
			q.setParameter("tipoEsquema", modoEnvio.toString());

			List<VersionScript> result = q.getResultList();

			return result == null || result.isEmpty() ? null : result;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<VersionScript> consultar(String esquema, Date fechaDesde,
			Date fechaHasta) throws GizloException {
		try {
			StringBuilder hqls = new StringBuilder(
					"select t from VersionScript t where 1=1 ");

			if (esquema != null && !esquema.isEmpty()) {
				hqls.append(" and t.tipoEsquema = :tipoEsquema");
			}
			if (fechaDesde != null) {
				hqls.append(" and t.fechaDesde >= :fechaDesde");
			}
			if (fechaHasta != null) {
				hqls.append(" and t.fechaHasta <= :fechaHasta");
			}
			Query q = em.createQuery(hqls.toString());
			if (esquema != null && !esquema.isEmpty()) {
				q.setParameter("tipoEsquema", esquema);
			}
			if (fechaDesde != null) {
				q.setParameter("fechaDesde", fechaDesde);
			}
			if (fechaHasta != null) {
				q.setParameter("fechaHasta", fechaHasta);
			}
			List<VersionScript> result = q.getResultList();

			return result == null || result.isEmpty() ? null : result;

		} catch (Exception e) {
			throw new GizloException("error al consultar versiones");
		}

	}

	@Override
	public boolean existeVersion(String esquema, Date fechaDesde,
			Date fechaHasta) throws GizloException {
		try {

			StringBuilder hqls = new StringBuilder(
					"select count (t) from VersionScript t where  t.tipoEsquema = :tipoEsquema  and ((:fechaDesde >=t.fechaDesde  and t.fechaHasta is null) or  ( :fechaDesde>=t.fechaDesde and :fechaHasta   <=t.fechaHasta ) )");

			Query q = em.createQuery(hqls.toString());

			q.setParameter("tipoEsquema", esquema);
			q.setParameter("fechaDesde", fechaDesde);
			q.setParameter("fechaHasta", fechaHasta);

			long result = (Long) q.getSingleResult();

			return result == 0 ? false : true;

		} catch (Exception e) {
			throw new GizloException("error al consultar si existe version");
		}

	}

	@Override
	public void eliminar(VersionScript version) throws GizloException {
		// TODO Auto-generated method stub
		try {
			this.delete(version);
		} catch (Exception e) {
			throw new GizloException("error al eliminar version");
		}
	}

}
