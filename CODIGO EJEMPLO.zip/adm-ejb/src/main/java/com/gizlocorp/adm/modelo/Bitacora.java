package com.gizlocorp.adm.modelo;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Bitacora implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long evento;

	private String usuario;

	private Date fecha;

	private Long organizacion;

	private String descripcion;

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getEvento() {
		return evento;
	}

	public void setEvento(Long evento) {
		this.evento = evento;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Long getOrganizacion() {
		return organizacion;
	}

	public void setOrganizacion(Long organizacion) {
		this.organizacion = organizacion;
	}

	public String getFechaStr() {
		if (fecha != null) {
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			return df.format(fecha);
		}
		return "";
	}

}
