package com.gizlocorp.adm.utilitario;

import java.io.Serializable;

public class MailMessage extends DeliveryMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1463735797285347068L;

}