package com.gizlocorp.adm.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
//import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.gizlocorp.adm.enumeracion.Logico;


@Entity
@Table(name = "tb_opcion")
public class Opcion implements Serializable {

	private static final long serialVersionUID = 1L;

	/*@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)*/
	@Id
	@SequenceGenerator(name = "seq_opcion", sequenceName = "seq_opcion", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_opcion")
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(nullable = false, length = 50)
	private String codigo;

	@Column(name = "nombre", length = 100, nullable = false)
	private String nombre;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_opcion_padre")
	private Opcion padre;

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "padre")
	private List<Opcion> subOpciones;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_rol")
	private Rol rol;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_recurso")
	private Modulo modulo;

	@Column(name = "lectura", length = 1, nullable = false)
	@Enumerated(EnumType.STRING)
	private Logico lectura;

	@Column(name = "insercion", length = 1, nullable = false)
	@Enumerated(EnumType.STRING)
	private Logico insercion;

	@Column(name = "modificacion", length = 1, nullable = false)
	@Enumerated(EnumType.STRING)
	private Logico modificacion;

	@Column(name = "eliminacion", length = 1, nullable = false)
	@Enumerated(EnumType.STRING)
	private Logico eliminacion;

	@Transient
	private boolean insercionBol;

	@Transient
	private boolean lecturaBol;

	@Transient
	private boolean modificacionBol;

	@Transient
	private boolean eliminacionBol;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Opcion getPadre() {
		return padre;
	}

	public void setPadre(Opcion padre) {
		this.padre = padre;
	}

	public List<Opcion> getSubOpciones() {
		return subOpciones;
	}

	public void setSubOpciones(List<Opcion> subOpciones) {
		this.subOpciones = subOpciones;
	}

	public Rol getRol() {
		return rol;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	public Modulo getModulo() {
		return modulo;
	}

	public void setModulo(Modulo modulo) {
		this.modulo = modulo;
	}

	public Logico getLectura() {
		return lectura;
	}

	public void setLectura(Logico lectura) {
		this.lectura = lectura;
	}

	public Logico getInsercion() {
		return insercion;
	}

	public void setInsercion(Logico insercion) {
		this.insercion = insercion;
	}

	public Logico getModificacion() {
		return modificacion;
	}

	public void setModificacion(Logico modificacion) {
		this.modificacion = modificacion;
	}

	public Logico getEliminacion() {
		return eliminacion;
	}

	public void setEliminacion(Logico eliminacion) {
		this.eliminacion = eliminacion;
	}

	public boolean isInsercionBol() {
		return insercionBol;
	}

	public void setInsercionBol(boolean insercionBol) {
		this.insercionBol = insercionBol;
	}

	public boolean isLecturaBol() {
		return lecturaBol;
	}

	public void setLecturaBol(boolean lecturaBol) {
		this.lecturaBol = lecturaBol;
	}

	public boolean isModificacionBol() {
		return modificacionBol;
	}

	public void setModificacionBol(boolean modificacionBol) {
		this.modificacionBol = modificacionBol;
	}

	public boolean isEliminacionBol() {
		return eliminacionBol;
	}

	public void setEliminacionBol(boolean eliminacionBol) {
		this.eliminacionBol = eliminacionBol;
	}

}
