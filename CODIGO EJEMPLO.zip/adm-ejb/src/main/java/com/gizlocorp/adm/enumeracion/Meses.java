package com.gizlocorp.adm.enumeracion;

public enum Meses {
	EN("01","Enero"), FBR("02","Febrero"),MAR("03","Marzo"),ABR("04","Abril"),
	MAY("05","Mayo"),JUN("06","Junio"),JUL("07","Julio"),AGO("08","Agosto"),SEPT("09","Septiembre")
	,OCT("10","Octubre"),NOV("11","Noviembre"),DIC("12","Diciembre");
	
	private String etiqueta;
	private String descripcion;

	private Meses(String descripcion, String etiqueta) {
		this.descripcion = descripcion;
		this.etiqueta = etiqueta;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public String getEtiqueta() {
		return etiqueta;
	}
}
