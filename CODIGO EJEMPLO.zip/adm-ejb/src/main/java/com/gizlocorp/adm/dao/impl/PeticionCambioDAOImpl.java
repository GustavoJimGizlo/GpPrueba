package com.gizlocorp.adm.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.gizlocorp.adm.dao.PeticionCambioDAO;
import com.gizlocorp.adm.enumeracion.Estado;
import com.gizlocorp.adm.modelo.PeticionCambio;

@Stateless
public class PeticionCambioDAOImpl extends GenericJpaDAO<PeticionCambio, Long> implements PeticionCambioDAO{

	
	@SuppressWarnings("unchecked")
	@Override
	public PeticionCambio buscarPeticion(String peticion) {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("select c from PeticionCambio c where 1=1 ");

		if(peticion != null && !peticion.isEmpty()){
			sql.append("and c.codigo = :peticion ");
			mapa.put("peticion", peticion);
		}
		
		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}
		
		List<PeticionCambio> result = q.getResultList();
		return result == null || result.isEmpty() ? null : result.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PeticionCambio> buscarPendientesUsuario(String usuario) {
		StringBuilder sql = new StringBuilder();
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		sql.append("SELECT c FROM PeticionCambio c WHERE 1=1 ");

		if(usuario != null && !usuario.isEmpty()){
			sql.append("AND c.username = :usuario ");
			mapa.put("usuario", usuario);
		}
		
		sql.append("AND c.estado = :estado ");
		mapa.put("estado", Estado.ACT);
		
		Query q = em.createQuery(sql.toString());
		for (String key : mapa.keySet()) {
			q.setParameter(key, mapa.get(key));
		}
		
		List<PeticionCambio> result = q.getResultList();
		return result == null || result.isEmpty() ? null : result;
	}

}
