/**
 * 
 */
package com.gizlocorp.adm.servicio.remote;

import java.util.List;

import javax.ejb.Remote;

import com.gizlocorp.adm.enumeracion.Logico;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.Organizacion;

/**
 * 
 * @author
 * @version
 */
@Remote
public interface ServicioOrganizacionRemote {
	List<Organizacion> listarOrganizaciones(String nombre, String acronimo,
			String ruc, Long idOrganizacion, Logico esEmisor)
			throws GizloException;

	void ingresarOrganizacion(Organizacion organizacion) throws GizloException;

	void actualizarOrganizacion(Organizacion parametro) throws GizloException;

	Organizacion consultarOrganizacion(String ruc) throws GizloException;

	List<Organizacion> listarActivas() throws GizloException;
}
