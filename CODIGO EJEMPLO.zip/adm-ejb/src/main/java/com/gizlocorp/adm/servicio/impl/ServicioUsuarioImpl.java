package com.gizlocorp.adm.servicio.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.jboss.security.auth.spi.Util;

import com.gizlocorp.adm.dao.OpcionDAO;
import com.gizlocorp.adm.dao.PeticionCambioDAO;
import com.gizlocorp.adm.dao.RecursoDAO;
import com.gizlocorp.adm.dao.UsuarioDAO;
import com.gizlocorp.adm.dao.UsuarioExternoDAO;
import com.gizlocorp.adm.dao.UsuarioRolDAO;
import com.gizlocorp.adm.excepcion.GizloDeleteException;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.excepcion.GizloPersistException;
import com.gizlocorp.adm.excepcion.GizloUpdateException;
import com.gizlocorp.adm.modelo.Modulo;
import com.gizlocorp.adm.modelo.Opcion;
import com.gizlocorp.adm.modelo.PeticionCambio;
import com.gizlocorp.adm.modelo.Usuario;
import com.gizlocorp.adm.modelo.UsuarioExterno;
import com.gizlocorp.adm.modelo.UsuarioRol;
import com.gizlocorp.adm.servicio.local.ServicioUsuarioLocal;

@Stateless
public class ServicioUsuarioImpl implements ServicioUsuarioLocal {

	@EJB
	UsuarioExternoDAO usuarioExternoDAO;
	@EJB
	UsuarioDAO usuarioDAO;
	@EJB
	RecursoDAO recursoDAO;
	@EJB
	OpcionDAO opcionDAO;
	@EJB
	UsuarioRolDAO usuarioRolDAO;
	@EJB
	PeticionCambioDAO peticionCambioDAO;

	public void guardarUsuarioExterno(UsuarioExterno usuarioExterno) {
		if (usuarioExterno.getId() == null) {
			try {
				String createPasswordHash = Util.createPasswordHash("SHA-256",
						"hex", null, null, usuarioExterno.getPassword());
				usuarioExterno.setPassword(createPasswordHash.toLowerCase());
				usuarioExternoDAO.persist(usuarioExterno);
			} catch (GizloPersistException e) {
				e.printStackTrace();
			}
		} else {
			try {
				usuarioExternoDAO.update(usuarioExterno);
			} catch (GizloUpdateException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public void eliminarUsuario(UsuarioExterno usuarioExterno)
			throws GizloException {
		try {
			List<UsuarioRol> roles = usuarioRolDAO
					.obtenerUsuarioRolPorUsuario(usuarioExterno);
			if (roles != null && !roles.isEmpty()) {
				for (UsuarioRol rol : roles) {
					usuarioRolDAO.delete(rol);
				}
			}
			usuarioExternoDAO.delete(usuarioExterno);
		} catch (GizloDeleteException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<UsuarioExterno> obtenerParametros(String nombres,
			String apellidos, String identificacion) {
		return usuarioExternoDAO.obtenerParametros(nombres, apellidos,
				identificacion);
	}

	@Override
	public List<Usuario> obtenerUsuarioParametros(String nombres,
			String apellidos, String identificacion) {
		return usuarioDAO.obtenerParametros(nombres, apellidos, identificacion);
	}

	@Override
	public Usuario obtenerUsuario(String username) {
		return usuarioDAO.obtenerUsuario(username);
	}

	@Override
	public UsuarioExterno obtenerUsuarioExterno(String username) {
		return usuarioExternoDAO.obtenerUsuarioExterno(username);
	}

	@Override
	public boolean tienePermiso(String username, String url)
			throws GizloException {
		boolean tienePermiso = false;
		Usuario usuario = usuarioDAO.obtenerUsuario(username);
		if (usuario == null) {
			throw new GizloException("No existe este usuario!");
		}
		List<UsuarioRol> roles = usuario.getUsuariosRoles();
		List<Opcion> opciones = null;

		if (roles != null && !roles.isEmpty()) {
			opciones = new ArrayList<Opcion>();
			Modulo recurso = (Modulo) recursoDAO.obtenerPorURL(url);
			if (recurso == null) {
				throw new GizloException("No existe esta url recurso!");
			}
			List<Opcion> opcionesTmp = null;
			for (UsuarioRol usuRol : roles) {
				opcionesTmp = opcionDAO.buscarPorRolModulo(usuRol.getRol(),
						recurso);
				if (opcionesTmp != null && !opcionesTmp.isEmpty()) {
					opciones.addAll(opcionDAO.buscarPorRolModulo(
							usuRol.getRol(), recurso));
				}
			}
		}

		if (opciones != null && !opciones.isEmpty()) {
			tienePermiso = true;
		}
		return tienePermiso;

	}

	@Override
	public boolean registrarPeticionCambioPassword(PeticionCambio pc) throws GizloException {
		try {
			List<PeticionCambio> lista = peticionCambioDAO.buscarPendientesUsuario(pc.getUsername());
			if(lista==null){
				Date fecha = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmssS");
				String strFecha =  sdf.format(fecha);
				pc.setCodigo(strFecha);
				pc.setFecha(fecha);
				peticionCambioDAO.persist(pc);
			}else{
				throw new GizloException("Existen peticiones pendientes de procesar");
			}
		} catch (GizloPersistException e) {
			e.printStackTrace();
			throw new GizloException(e.getMessage());
		}
		return true;
	}

	@Override
	public PeticionCambio buscarPeticion(String peticion) throws GizloException{
		PeticionCambio a = peticionCambioDAO.buscarPeticion(peticion);
		return a;
	}

	@Override
	public boolean actualizarPeticionCambioPassword(PeticionCambio pc) throws GizloException{
		try {
			peticionCambioDAO.update(pc);
		} catch (GizloUpdateException e) {
			e.printStackTrace();
			throw new GizloException(e.getMessage());
		}
		return true;
	}

}
