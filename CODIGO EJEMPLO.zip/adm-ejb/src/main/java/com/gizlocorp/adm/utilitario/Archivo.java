package com.gizlocorp.adm.utilitario;

import java.io.Serializable;
import java.util.Arrays;

public class Archivo implements Serializable{

	private static final long serialVersionUID = 5557699544958526135L;
	private byte [] bytes;
	private String extension;
	private String nombre;
	
	public Archivo() {
	}
	public Archivo(byte[] bytes, String extension, String nombre) {
		this.bytes = bytes;
		this.extension = extension;
		this.nombre = nombre;
	}
	public byte[] getBytes() {
		return bytes;
	}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Archivo [bytes=" + Arrays.toString(bytes) + ", extension=" + extension + ", nombre=" + nombre + "]";
	}	
	
}
