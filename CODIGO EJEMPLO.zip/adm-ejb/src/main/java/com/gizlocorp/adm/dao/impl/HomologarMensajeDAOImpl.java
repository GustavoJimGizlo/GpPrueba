package com.gizlocorp.adm.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.gizlocorp.adm.dao.HomologarMensajesDAO;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.HomologarMensaje;

/**
 * @author 
 * 
 */

@Stateless
public class HomologarMensajeDAOImpl extends GenericJpaDAO<HomologarMensaje, Long> implements HomologarMensajesDAO {

	@Override
	public List<HomologarMensaje> obtenerMensajes(String nombre,
			String errorAplicacion) throws GizloException {
		try {
			StringBuilder sql = new StringBuilder();
			HashMap<String, Object> mapa = new HashMap<String, Object>();
			sql.append("select p from HomologarMensaje p where 1=1");

			if (nombre != null && !nombre.isEmpty()) {
				sql.append("and p.nombre = :nombre ");
				mapa.put("nombre", nombre);
			}

			if (errorAplicacion != null && !errorAplicacion.isEmpty()) {
				sql.append("and p.errorAplicacion = :errorAplicacion ");
				mapa.put("errorAplicacion", errorAplicacion);
			}


			Query q = em.createQuery(sql.toString());
			for (String key : mapa.keySet()) {
				q.setParameter(key, mapa.get(key));
			}

			List<HomologarMensaje> result = q.getResultList();
			return result == null || result.isEmpty() ? null : result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	

	

}
