/**
 * 
 */
package com.gizlocorp.adm.servicio.local;

import javax.ejb.Local;



/**
 * 
 * @author 
 * @version 
 */
@Local
public interface ServicioEstudianteLocal {

		public void prueba() ;
}
