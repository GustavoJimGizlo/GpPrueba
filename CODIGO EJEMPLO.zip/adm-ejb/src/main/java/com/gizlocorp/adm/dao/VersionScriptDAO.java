package com.gizlocorp.adm.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import com.gizlocorp.adm.enumeracion.ModoEnvio;
import com.gizlocorp.adm.excepcion.GizloException;
import com.gizlocorp.adm.modelo.VersionScript;

@Local
public interface VersionScriptDAO extends GenericDAO<VersionScript, Long> {

   List<VersionScript> cargarRuta(ModoEnvio modoEnvio) throws GizloException;
   List<VersionScript> consultar(String esquema, Date fechaDesde,Date fechaHasta) throws GizloException;
   boolean existeVersion(String esquema, Date fechaDesde,Date fechaHasta)  throws GizloException;
   void eliminar(VersionScript version) throws GizloException;
}
